#pragma once

namespace Implementation {
    class Buzzer {
        bool playing;

    public:
        class {
        public:
            int Loud;
            int Quiet;
        } Volume;

        class {
        public:
            int A;
            int ASharp;
            int B;
            int C;
            int CSharp;
            int D;
            int DSharp;
            int E;
            int F;
            int FSharp;
            int G;
            int GSharp;
        } Note;

        Buzzer();

        void SetVolume(int volume);
        void PlayNote(int note);
        void PlayFrequency(int frequency);
        void Stop();
    };
}
