#pragma once

class Color {
public:
    static Color Black;
    static Color White;
    static Color Red;
    static Color Green;
    static Color Blue;
    static Color Yellow;
    static Color Cyan;
    static Color Magenta;

    unsigned char R;
    unsigned char G;
    unsigned char B;

    Color();
    Color(unsigned char r, unsigned char g, unsigned char b);

    unsigned short As565();
};
