#pragma once

#include "Color.h"

namespace Implementation {
    class TrafficLight {
        void SetColor(Color color, int level);

    public:
        TrafficLight();

        void TurnRedLightOn();
        void TurnRedLightOff();
        void TurnYellowLightOn();
        void TurnYellowLightOff();
        void TurnGreenLightOn();
        void TurnGreenLightOff();
        void TurnOffAllLights();
        void TurnColorOn(Color color);
        void TurnColorOff(Color color);
    };
}
