#include "Wait.h"

#ifdef VS
    #include "../Visual Studio/Helpers.h"
#else
    #include <Arduino.h>
#endif

using namespace Implementation;

void Wait::Seconds(double seconds) {
    if (seconds < 0.0) return;

    this->Milliseconds(seconds * 1000.0);
}

void Wait::Milliseconds(double milliseconds) {
    if (milliseconds < 0.0) return;

    delay((unsigned long)milliseconds);
}