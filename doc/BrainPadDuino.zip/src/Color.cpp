#include "Color.h"

Color Color::Black(0, 0, 0);
Color Color::White(255, 255, 255);
Color Color::Red(255, 0, 0);
Color Color::Green(0, 255, 0);
Color Color::Blue(0, 0, 255);
Color Color::Yellow(255, 255, 0);
Color Color::Cyan(0, 255, 255);
Color Color::Magenta(255, 0, 255);

Color::Color() : Color(0, 0, 0) {

}

Color::Color(unsigned char r, unsigned char g, unsigned char b) {
    this->R = r;
    this->G = g;
    this->B = b;
}

unsigned short Color::As565() {
    return (unsigned short)(((this->R & 0x1F) << 11) | ((this->G & 0x3F) << 5) | (this->B & 0x1F));
}
