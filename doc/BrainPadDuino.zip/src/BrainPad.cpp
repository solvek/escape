#include "BrainPad.h"

#ifdef VS
    #include "../Visual Studio/Helpers.h"
#else
    #include <Arduino.h>
#endif

using namespace Implementation;

Implementation::BrainPad BrainPad;

BrainPad::BrainPad() {
    this->serialBegan = false;
    this->Looping = true;
}

void BrainPad::WriteDebugMessage(const char* message) {
    if (!this->serialBegan) {
        Serial.begin(9600);
        this->serialBegan = true;
    }

    Serial.println(message);
}

void BrainPad::WriteDebugMessage(int message) {
    if (!this->serialBegan) {
        Serial.begin(9600);
        this->serialBegan = true;
    }

    Serial.println(message);
}

void BrainPad::WriteDebugMessage(double message) {
    if (!this->serialBegan) {
        Serial.begin(9600);
        this->serialBegan = true;
    }

    Serial.println(message);
}
