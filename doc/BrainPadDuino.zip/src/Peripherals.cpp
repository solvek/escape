#include "Peripherals.h"

using namespace Implementation;

Implementation::Peripherals Peripherals;

Peripherals::Peripherals() {
    this->Display.ChipSelect = 53;
    this->Display.Control = 34;
    this->Display.Reset = 33;
    this->Display.Backlight = 5;

    this->TrafficLight.Red = 8;
    this->TrafficLight.Yellow = 7;
    this->TrafficLight.Green = 6;

    this->Button.Up = 42;
    this->Button.Down = 48;
    this->Button.Left = 43;
    this->Button.Right = 47;

    this->LightBulb.Red = 45;
    this->LightBulb.Green = 46;
    this->LightBulb.Blue = 44;

    this->TemperatureSensor = 14;
    this->LightSensor = 15;
    this->Buzzer = 10;
    this->BuzzerVolumeController = 32;
    this->DcMotor = 4;
    this->ServoMotor = 9;
}