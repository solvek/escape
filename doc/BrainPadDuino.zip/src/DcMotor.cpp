#include "DcMotor.h"

#include "Peripherals.h"

#ifdef VS
    #include "../Visual Studio/Helpers.h"
#else
    #include <Arduino.h>
#endif

using namespace Implementation;

void DcMotor::SetSpeed(double speed) {
    if (speed < 0.0) return;

    analogWrite(::Peripherals.DcMotor, (int)(speed * 255.0));
}

void DcMotor::Stop() {
    this->SetSpeed(0.0);
}

