#pragma once

#include "Color.h"
#include "Image.h"
#include "DcMotor.h"
#include "ServoMotor.h"
#include "LightBulb.h"
#include "Buzzer.h"
#include "Button.h"
#include "TrafficLight.h"
#include "LightSensor.h"
#include "TemperatureSensor.h"
#include "Accelerometer.h"
#include "Display.h"
#include "Wait.h"
#include "Expansion.h"
#include "Peripherals.h"

namespace Implementation {
    class BrainPad {
        bool serialBegan;

    public:
        BrainPad();

        bool Looping;

        void WriteDebugMessage(const char* message);
        void WriteDebugMessage(int message);
        void WriteDebugMessage(double message);
    
        Implementation::DcMotor DcMotor;
        Implementation::ServoMotor ServoMotor;
        Implementation::LightBulb LightBulb;
        Implementation::Buzzer Buzzer;
        Implementation::Button Button;
        Implementation::TrafficLight TrafficLight;
        Implementation::LightSensor LightSensor;
        Implementation::TemperatureSensor TemperatureSensor;
        Implementation::Accelerometer Accelerometer;
        Implementation::Display Display;
        Implementation::Wait Wait;
    };
}

extern Implementation::BrainPad BrainPad;
