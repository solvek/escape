#pragma once

namespace Implementation {
    class Peripherals {
    public:
        Peripherals();

        class {
        public:
            int ChipSelect;
            int Control;
            int Reset;
            int Backlight;
        } Display;

        class {
        public:
            int Red;
            int Yellow;
            int Green;
        } TrafficLight;

        class {
        public:
            int Up;
            int Down;
            int Left;
            int Right;
        } Button;

        class {
        public:
            int Red;
            int Green;
            int Blue;
        } LightBulb;

        int TemperatureSensor;
        int LightSensor;
        int Buzzer;
        int BuzzerVolumeController;
        int DcMotor;
        int ServoMotor;
    };
}

extern Implementation::Peripherals Peripherals;
