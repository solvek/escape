#pragma once

namespace Implementation {
    class Wait {
    public:
        void Seconds(double seconds);
        void Milliseconds(double milliseconds);
    };
}
