#include "Accelerometer.h"

#ifdef VS
    #include "../Visual Studio/Helpers.h"
#else
    #include <Wire.h>
#endif

using namespace Implementation;

Accelerometer::Accelerometer() {
    this->started = false;
}

double Accelerometer::ReadAxis(unsigned char reg) {
    if (!this->started) {
        Wire.begin();

        Wire.beginTransmission(0x1C);

        this->buffer[0] = 0x2A;
        this->buffer[1] = 0x01;

        Wire.write(this->buffer, 2);

        Wire.endTransmission();

        this->started = true;
    }

    Wire.beginTransmission(0x1C);
    Wire.write(reg);
    Wire.endTransmission(false);
    
    Wire.requestFrom(0x1C, 2, true);

    while (Wire.available() < 2)
        ;

    this->buffer[0] = Wire.read();
    this->buffer[1] = Wire.read();

    double value = this->buffer[0] << 2 | this->buffer[1] >> 6;

    if (value > 511.0)
        value -= 1024.0;

    return value / 256.0;
}

double Accelerometer::ReadX() {
    return this->ReadAxis(1);
}

double Accelerometer::ReadY() {
    return this->ReadAxis(3);
}

double Accelerometer::ReadZ() {
    return this->ReadAxis(5);
}
