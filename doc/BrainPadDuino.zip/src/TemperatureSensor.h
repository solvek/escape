#pragma once

namespace Implementation {
    class TemperatureSensor {
    public:
        double ReadTemperature();
    };
}
