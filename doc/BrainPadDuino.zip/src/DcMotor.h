#pragma once

namespace Implementation {
    class DcMotor {
    public:
        void SetSpeed(double speed);
        void Stop();
    };
}
