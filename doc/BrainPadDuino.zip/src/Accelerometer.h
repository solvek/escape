#pragma once

namespace Implementation {
    class Accelerometer {
        bool started;
        unsigned char buffer[2];

        double ReadAxis(unsigned char reg);

    public:
        Accelerometer();

        double ReadX();
        double ReadY();
        double ReadZ();
    };
}
