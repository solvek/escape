#include "Expansion.h"

using namespace Implementation;

Implementation::Expansion Expansion;

Expansion::Expansion() {
    this->Gpio.D11 = 11;
    this->Gpio.D12 = 12;
    this->Gpio.D3 = 3;
    this->Gpio.D2 = 2;
    this->Gpio.D19 = 19;
    this->Gpio.D18 = 18;

    this->Pwm.D11 = 11;
    this->Pwm.D12 = 12;
    this->Pwm.D3 = 3;
    this->Pwm.D2 = 2;

    this->AnalogInput.A13 = 13;
}
