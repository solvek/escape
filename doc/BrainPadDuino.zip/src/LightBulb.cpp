#include "LightBulb.h"

#include "Peripherals.h"

#ifdef VS
    #include "../Visual Studio/Helpers.h"
#else
    #include <Arduino.h>
#endif

using namespace Implementation;

LightBulb::LightBulb() {
    pinMode(::Peripherals.LightBulb.Red, OUTPUT);
    pinMode(::Peripherals.LightBulb.Green, OUTPUT);
    pinMode(::Peripherals.LightBulb.Blue, OUTPUT);
}

void LightBulb::SetColor(Color color) {
    this->SetColor(color.R, color.G, color.B);
}

void LightBulb::SetColor(double r, double g, double b) {
    if (r > 255.0) r = 255.0;
    if (r < 0.0) r = 0.0;
    if (g > 255.0) g = 255.0;
    if (g < 0.0) g = 0.0;
    if (b > 255.0) b = 255.0;
    if (b < 0.0) b = 0.0;

    this->r = (int)r;
    this->g = (int)g;
    this->b = (int)b;

    this->TurnOn();
}

void LightBulb::TurnOn() {
    analogWrite(::Peripherals.LightBulb.Red, this->r);
    analogWrite(::Peripherals.LightBulb.Green, this->g);
    analogWrite(::Peripherals.LightBulb.Blue, this->b);
}

void LightBulb::TurnOff() {
    analogWrite(::Peripherals.LightBulb.Red, 0);
    analogWrite(::Peripherals.LightBulb.Green, 0);
    analogWrite(::Peripherals.LightBulb.Blue, 0);
}
