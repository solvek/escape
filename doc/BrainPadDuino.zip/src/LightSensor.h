#pragma once

namespace Implementation {
    class LightSensor {
    public:
        double ReadLightLevel();
    };
}
