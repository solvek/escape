#include "ServoMotor.h"

#include "Peripherals.h"

using namespace Implementation;

void ServoMotor::SetPosition(int position) {
    if (position < 0) position = 0;
    if (position > 180) position = 180;

    this->Start();

    this->servo.write(position);
}

void ServoMotor::Start() {
    this->servo.attach(::Peripherals.ServoMotor, 1000, 2000);
}

void ServoMotor::Stop() {
    this->servo.detach();
}

