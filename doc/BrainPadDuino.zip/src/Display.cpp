#include "Display.h"

#include "Peripherals.h"

#ifndef VS
#include <Arduino.h>
#include <avr/pgmspace.h>
#endif

#define Abs(x) ((x) > 0 ? (x) : -(x))

using namespace Implementation;

const PROGMEM unsigned char font[] = {
    0x00, 0x00, 0x00, 0x00, 0x00, /* Space	0x20 */
    0x00, 0x00, 0x4f, 0x00, 0x00, /* ! */
    0x00, 0x07, 0x00, 0x07, 0x00, /* " */
    0x14, 0x7f, 0x14, 0x7f, 0x14, /* # */
    0x24, 0x2a, 0x7f, 0x2a, 0x12, /* $ */
    0x23, 0x13, 0x08, 0x64, 0x62, /* % */
    0x36, 0x49, 0x55, 0x22, 0x20, /* & */
    0x00, 0x05, 0x03, 0x00, 0x00, /* ' */
    0x00, 0x1c, 0x22, 0x41, 0x00, /* ( */
    0x00, 0x41, 0x22, 0x1c, 0x00, /* ) */
    0x14, 0x08, 0x3e, 0x08, 0x14, /* // */
    0x08, 0x08, 0x3e, 0x08, 0x08, /* + */
    0x50, 0x30, 0x00, 0x00, 0x00, /* , */
    0x08, 0x08, 0x08, 0x08, 0x08, /* - */
    0x00, 0x60, 0x60, 0x00, 0x00, /* . */
    0x20, 0x10, 0x08, 0x04, 0x02, /* / */
    0x3e, 0x51, 0x49, 0x45, 0x3e, /* 0		0x30 */
    0x00, 0x42, 0x7f, 0x40, 0x00, /* 1 */
    0x42, 0x61, 0x51, 0x49, 0x46, /* 2 */
    0x21, 0x41, 0x45, 0x4b, 0x31, /* 3 */
    0x18, 0x14, 0x12, 0x7f, 0x10, /* 4 */
    0x27, 0x45, 0x45, 0x45, 0x39, /* 5 */
    0x3c, 0x4a, 0x49, 0x49, 0x30, /* 6 */
    0x01, 0x71, 0x09, 0x05, 0x03, /* 7 */
    0x36, 0x49, 0x49, 0x49, 0x36, /* 8 */
    0x06, 0x49, 0x49, 0x29, 0x1e, /* 9 */
    0x00, 0x36, 0x36, 0x00, 0x00, /* : */
    0x00, 0x56, 0x36, 0x00, 0x00, /* ; */
    0x08, 0x14, 0x22, 0x41, 0x00, /* < */
    0x14, 0x14, 0x14, 0x14, 0x14, /* = */
    0x00, 0x41, 0x22, 0x14, 0x08, /* > */
    0x02, 0x01, 0x51, 0x09, 0x06, /* ? */
    0x3e, 0x41, 0x5d, 0x55, 0x1e, /* @		0x40 */
    0x7e, 0x11, 0x11, 0x11, 0x7e, /* A */
    0x7f, 0x49, 0x49, 0x49, 0x36, /* B */
    0x3e, 0x41, 0x41, 0x41, 0x22, /* C */
    0x7f, 0x41, 0x41, 0x22, 0x1c, /* D */
    0x7f, 0x49, 0x49, 0x49, 0x41, /* E */
    0x7f, 0x09, 0x09, 0x09, 0x01, /* F */
    0x3e, 0x41, 0x49, 0x49, 0x7a, /* G */
    0x7f, 0x08, 0x08, 0x08, 0x7f, /* H */
    0x00, 0x41, 0x7f, 0x41, 0x00, /* I */
    0x20, 0x40, 0x41, 0x3f, 0x01, /* J */
    0x7f, 0x08, 0x14, 0x22, 0x41, /* K */
    0x7f, 0x40, 0x40, 0x40, 0x40, /* L */
    0x7f, 0x02, 0x0c, 0x02, 0x7f, /* M */
    0x7f, 0x04, 0x08, 0x10, 0x7f, /* N */
    0x3e, 0x41, 0x41, 0x41, 0x3e, /* O */
    0x7f, 0x09, 0x09, 0x09, 0x06, /* P		0x50 */
    0x3e, 0x41, 0x51, 0x21, 0x5e, /* Q */
    0x7f, 0x09, 0x19, 0x29, 0x46, /* R */
    0x26, 0x49, 0x49, 0x49, 0x32, /* S */
    0x01, 0x01, 0x7f, 0x01, 0x01, /* T */
    0x3f, 0x40, 0x40, 0x40, 0x3f, /* U */
    0x1f, 0x20, 0x40, 0x20, 0x1f, /* V */
    0x3f, 0x40, 0x38, 0x40, 0x3f, /* W */
    0x63, 0x14, 0x08, 0x14, 0x63, /* X */
    0x07, 0x08, 0x70, 0x08, 0x07, /* Y */
    0x61, 0x51, 0x49, 0x45, 0x43, /* Z */
    0x00, 0x7f, 0x41, 0x41, 0x00, /* [ */
    0x02, 0x04, 0x08, 0x10, 0x20, /* \ */
    0x00, 0x41, 0x41, 0x7f, 0x00, /* ] */
    0x04, 0x02, 0x01, 0x02, 0x04, /* ^ */
    0x40, 0x40, 0x40, 0x40, 0x40, /* _ */
    0x00, 0x00, 0x03, 0x05, 0x00, /* `		0x60 */
    0x20, 0x54, 0x54, 0x54, 0x78, /* a */
    0x7F, 0x44, 0x44, 0x44, 0x38, /* b */
    0x38, 0x44, 0x44, 0x44, 0x44, /* c */
    0x38, 0x44, 0x44, 0x44, 0x7f, /* d */
    0x38, 0x54, 0x54, 0x54, 0x18, /* e */
    0x04, 0x04, 0x7e, 0x05, 0x05, /* f */
    0x08, 0x54, 0x54, 0x54, 0x3c, /* g */
    0x7f, 0x08, 0x04, 0x04, 0x78, /* h */
    0x00, 0x44, 0x7d, 0x40, 0x00, /* i */
    0x20, 0x40, 0x44, 0x3d, 0x00, /* j */
    0x7f, 0x10, 0x28, 0x44, 0x00, /* k */
    0x00, 0x41, 0x7f, 0x40, 0x00, /* l */
    0x7c, 0x04, 0x7c, 0x04, 0x78, /* m */
    0x7c, 0x08, 0x04, 0x04, 0x78, /* n */
    0x38, 0x44, 0x44, 0x44, 0x38, /* o */
    0x7c, 0x14, 0x14, 0x14, 0x08, /* p		0x70 */
    0x08, 0x14, 0x14, 0x14, 0x7c, /* q */
    0x7c, 0x08, 0x04, 0x04, 0x00, /* r */
    0x48, 0x54, 0x54, 0x54, 0x24, /* s */
    0x04, 0x04, 0x3f, 0x44, 0x44, /* t */
    0x3c, 0x40, 0x40, 0x20, 0x7c, /* u */
    0x1c, 0x20, 0x40, 0x20, 0x1c, /* v */
    0x3c, 0x40, 0x30, 0x40, 0x3c, /* w */
    0x44, 0x28, 0x10, 0x28, 0x44, /* x */
    0x0c, 0x50, 0x50, 0x50, 0x3c, /* y */
    0x44, 0x64, 0x54, 0x4c, 0x44, /* z */
    0x08, 0x36, 0x41, 0x41, 0x00, /* { */
    0x00, 0x00, 0x77, 0x00, 0x00, /* | */
    0x00, 0x41, 0x41, 0x36, 0x08, /* } */
    0x08, 0x08, 0x2a, 0x1c, 0x08  /* ~ */
};

//regular delay crashes the board when used here.
static void customDelay(unsigned long long ms) {
    ms *= 1000;
    ms /= 10000;

    while (ms--)
        delayMicroseconds(10000);
}

Display::Display() : settings(12000000, MSBFIRST, SPI_MODE0) {
    pinMode(::Peripherals.Display.Backlight, OUTPUT);
    pinMode(::Peripherals.Display.Reset, OUTPUT);
    pinMode(::Peripherals.Display.Control, OUTPUT);
    pinMode(::Peripherals.Display.ChipSelect, OUTPUT);

    digitalWrite(::Peripherals.Display.Backlight, HIGH);
    digitalWrite(::Peripherals.Display.Reset, LOW);
    digitalWrite(::Peripherals.Display.Control, LOW);
    digitalWrite(::Peripherals.Display.ChipSelect, HIGH);

    SPI.begin();

    Reset();

    WriteCommand(0x11); //Sleep exit 
    customDelay(120);

    // ST7735R Frame Rate
    WriteCommand(0xB1);
    WriteData(0x01); WriteData(0x2C); WriteData(0x2D);
    WriteCommand(0xB2);
    WriteData(0x01); WriteData(0x2C); WriteData(0x2D);
    WriteCommand(0xB3);
    WriteData(0x01); WriteData(0x2C); WriteData(0x2D);
    WriteData(0x01); WriteData(0x2C); WriteData(0x2D);

    WriteCommand(0xB4); // Column inversion 
    WriteData(0x07);

    // ST7735R Power Sequence
    WriteCommand(0xC0);
    WriteData(0xA2); WriteData(0x02); WriteData(0x84);
    WriteCommand(0xC1); WriteData(0xC5);
    WriteCommand(0xC2);
    WriteData(0x0A); WriteData(0x00);
    WriteCommand(0xC3);
    WriteData(0x8A); WriteData(0x2A);
    WriteCommand(0xC4);
    WriteData(0x8A); WriteData(0xEE);

    WriteCommand(0xC5); // VCOM 
    WriteData(0x0E);

    WriteCommand(0x36); // MX, MY, RGB mode
    WriteData(MADCTL_MX | MADCTL_MY | MADCTL_BGR);

    // ST7735R Gamma Sequence
    WriteCommand(0xe0);
    WriteData(0x0f); WriteData(0x1a);
    WriteData(0x0f); WriteData(0x18);
    WriteData(0x2f); WriteData(0x28);
    WriteData(0x20); WriteData(0x22);
    WriteData(0x1f); WriteData(0x1b);
    WriteData(0x23); WriteData(0x37); WriteData(0x00);

    WriteData(0x07);
    WriteData(0x02); WriteData(0x10);
    WriteCommand(0xe1);
    WriteData(0x0f); WriteData(0x1b);
    WriteData(0x0f); WriteData(0x17);
    WriteData(0x33); WriteData(0x2c);
    WriteData(0x29); WriteData(0x2e);
    WriteData(0x30); WriteData(0x30);
    WriteData(0x39); WriteData(0x3f);
    WriteData(0x00); WriteData(0x07);
    WriteData(0x03); WriteData(0x10);

    WriteCommand(0x2a);
    WriteData(0x00); WriteData(0x00);
    WriteData(0x00); WriteData(0x7f);
    WriteCommand(0x2b);
    WriteData(0x00); WriteData(0x00);
    WriteData(0x00); WriteData(0x9f);

    WriteCommand(0xF0); //Enable test command  
    WriteData(0x01);
    WriteCommand(0xF6); //Disable ram power save mode 
    WriteData(0x00);

    WriteCommand(0x3A); //65k mode 
    WriteData(0x05);

    // Rotate
    WriteCommand(ST7735_MADCTL);
    WriteData(MADCTL_MV | MADCTL_MY);

    WriteCommand(0x29); //Display on
    customDelay(50);
    
    Clear();
}

void Display::SpiWrite(unsigned char* buffer, int length) {
    SPI.beginTransaction(this->settings);
    digitalWrite(::Peripherals.Display.ChipSelect, LOW);

    for (int i = 0; i < length; i++)
        SPI.transfer(buffer[i]);

    digitalWrite(::Peripherals.Display.ChipSelect, HIGH);
    SPI.endTransaction();
}

void Display::WriteData(unsigned char* data, int length) {
    digitalWrite(::Peripherals.Display.Control, HIGH);
    SpiWrite(data, length);
}

void Display::WriteCommand(unsigned char command) {
    buffer1[0] = command;
    digitalWrite(::Peripherals.Display.Control, LOW);
    SpiWrite(buffer1, 1);
}

void Display::WriteData(unsigned char data) {
    buffer1[0] = data;
    digitalWrite(::Peripherals.Display.Control, HIGH);
    SpiWrite(buffer1, 1);
}

void Display::Reset() {
    digitalWrite(::Peripherals.Display.Reset, LOW);
    customDelay(300);
    digitalWrite(::Peripherals.Display.Reset, HIGH);
    customDelay(1000);
}

void Display::SetClip(int x, int y, int width, int height) {
    WriteCommand(0x2A);

    digitalWrite(::Peripherals.Display.Control, HIGH);
    buffer4[1] = (unsigned char)x;
    buffer4[3] = (unsigned char)(x + width - 1);
    SpiWrite(buffer4, 4);

    WriteCommand(0x2B);
    digitalWrite(::Peripherals.Display.Control, HIGH);
    buffer4[1] = (unsigned char)y;
    buffer4[3] = (unsigned char)(y + height - 1);
    SpiWrite(buffer4, 4);
}

void Display::Clear() {
    SetClip(0, 0, 160, 128);
    WriteCommand(0x2C);

    for (int i = 0; i < 128; i++)
        WriteData(clearBuffer, sizeof(clearBuffer));
}

void Display::TurnOn() {
    digitalWrite(::Peripherals.Display.Backlight, HIGH);
}

void Display::TurnOff() {
    digitalWrite(::Peripherals.Display.Backlight, LOW);
}

void Display::SetPixel(int x, int y, Color color) {
    SetClip(x, y, 1, 1);

    buffer2[0] = (unsigned char)(color.As565() >> 8);
    buffer2[1] = (unsigned char)(color.As565() >> 0);

    DrawImage(buffer2, 2);
}

void Display::DrawImage(unsigned char* data, int length) {
    if (length <= 0) return;
    if (!data) return;

    WriteCommand(0x2C);
    WriteData(data, length);
}

void Display::DrawImage(int x, int y, const Image& image) {
    if (x < 0 || y < 0 || x + image.Width >= Width || y + image.Height >= Height) return;

    SetClip(x, y, image.Width, image.Height);
    DrawImage(image.Pixels, image.Width * image.Height * 2);
}

void Display::DrawLine(int x0, int y0, int x1, int y1, Color color) {
    if (x0 < 0 || y0 < 0 || x1 < 0 || y1 < 0) return;
    if (x0 >= Width || y0 >= Height || x1 >= Width || y1 >= Height) return;

    int steep = Abs(y1 - y0) > Abs(x1 - x0);
    int t, dX, dY, yStep, error;

    if (steep) {
        t = x0;
        x0 = y0;
        y0 = t;
        t = x1;
        x1 = y1;
        y1 = t;
    }

    if (x0 > x1) {
        t = x0;
        x0 = x1;
        x1 = t;

        t = y0;
        y0 = y1;
        y1 = t;
    }

    dX = x1 - x0;
    dY = Abs(y1 - y0);

    error = (dX / 2);

    if (y0 < y1) {
        yStep = 1;
    }
    else {
        yStep = -1;
    }

    for (; x0 < x1; x0++) {
        if (steep) {
            SetPixel(y0, x0, color);
        }
        else {
            SetPixel(x0, y0, color);
        }

        error -= dY;

        if (error < 0) {
            y0 += (unsigned char)yStep;
            error += dX;
        }
    }
}

void Display::DrawCircle(int x, int y, int r, Color color) {
    if (x - r < 0 || y - r < 0 || x + r >= Width || y + r >= Height) return;

    int f = 1 - r;
    int ddFX = 1;
    int ddFY = -2 * r;
    int dX = 0;
    int dY = r;

    SetPixel(x, y + r, color);
    SetPixel(x, y - r, color);
    SetPixel(x + r, y, color);
    SetPixel(x - r, y, color);

    while (dX < dY) {
        if (f >= 0) {
            dY--;
            ddFY += 2;
            f += ddFY;
        }

        dX++;
        ddFX += 2;
        f += ddFX;

        SetPixel(x + dX, y + dY, color);
        SetPixel(x - dX, y + dY, color);
        SetPixel(x + dX, y - dY, color);
        SetPixel(x - dX, y - dY, color);

        SetPixel(x + dY, y + dX, color);
        SetPixel(x - dY, y + dX, color);
        SetPixel(x + dY, y - dX, color);
        SetPixel(x - dY, y - dX, color);
    }
}

void Display::DrawRectangle(int x, int y, int width, int height, Color color) {
    if (x < 0 || y < 0 || x + width >= Width || y + height >= Height) return;

    for (int i = x; i < x + width; i++) {
        SetPixel(i, y, color);
        SetPixel(i, y + height - 1, color);
    }

    for (int i = y; i < y + height; i++) {
        SetPixel(x, i, color);
        SetPixel(x + width - 1, i, color);
    }
}

void Display::DrawFilledrectangle(int x, int y, int width, int height, Color color) {
    if (x < 0 || y < 0 || x + width >= Width || y + height >= Height) return;

    SetClip(x, y, width, height);

    unsigned char* data = new unsigned char[width * height * 2];
    for (int i = 0; i < width * height * 2; i += 2) {
        data[i] = (unsigned char)((color.As565() >> 8) & 0xFF);
        data[i + 1] = (unsigned char)((color.As565() >> 0) & 0xFF);
    }

    DrawImage(data, width * height * 2);

    delete[] data;
}

void Display::DrawLetter(int x, int y, char letter, Color color, int scaleFactor) {
    if (x < 0 || y < 0 || x + 6 * scaleFactor >= Width || y + 8 * scaleFactor >= Height) return;

    int index = 5 * (letter - 32);
    unsigned char upper = (unsigned char)(color.As565() >> 8);
    unsigned char lower = (unsigned char)(color.As565() >> 0);
    unsigned char* characterBuffer = scaleFactor == 1 ? characterBuffer1 : (scaleFactor == 2 ? characterBuffer2 : characterBuffer4);

    int i = 0;

    for (int j = 1; j <= 64; j *= 2) {
        for (int k = 0; k < scaleFactor; k++) {
            for (int l = 0; l < 5; l++) {
                for (int m = 0; m < scaleFactor; m++) {
                    int show = (pgm_read_byte_near(font + index + l) & j) != 0;

                    characterBuffer[i++] = show ? upper : (unsigned char)0x00;
                    characterBuffer[i++] = show ? lower : (unsigned char)0x00;
                }
            }
        }
    }

    SetClip(x, y, 5 * scaleFactor, 8 * scaleFactor);
    DrawImage(characterBuffer, scaleFactor == 1 ? 80 : (scaleFactor == 2 ? 320 : 1280));
}

void Display::DrawLetter(int x, int y, char letter, Color color) {
    if (letter < 32 || letter > 126) return;

    DrawLetter(x, y, letter, color, 1);
}

void Display::DrawLargeLetter(int x, int y, char letter, Color color) {
    if (letter < 32 || letter > 126) return;

    DrawLetter(x, y, letter, color, 2);
}

void Display::DrawExtraLargeLetter(int x, int y, char letter, Color color) {
    if (letter < 32 || letter > 126) return;

    DrawLetter(x, y, letter, color, 4);
}

void Display::DrawText(int x, int y, const char* text, Color color) {
    if (!text) return;

    for (int i = 0; text[i]; i++)
        DrawLetter(x + i * 6, y, text[i], color);
}

void Display::DrawLargeText(int x, int y, const char* text, Color color) {
    if (!text) return;

    for (int i = 0; text[i]; i++)
        DrawLargeLetter(x + i * 6 * 2, y, text[i], color);
}

void Display::DrawExtraLargeText(int x, int y, const char* text, Color color) {
    if (!text) return;

    for (int i = 0; text[i]; i++)
        DrawExtraLargeLetter(x + i * 6 * 4, y, text[i], color);
}

void Display::DrawNumber(int x, int y, double number, Color color) {
    this->DrawText(x, y, String(number, 2).c_str(), color);
}

void Display::DrawLargeNumber(int x, int y, double number, Color color) {
    this->DrawLargeText(x, y, String(number, 2).c_str(), color);
}

void Display::DrawExtraLargeNumber(int x, int y, double number, Color color) {
    this->DrawExtraLargeText(x, y, String(number, 2).c_str(), color);
}

void Display::DrawNumber(int x, int y, int number, Color color) {
    this->DrawText(x, y, String(number, DEC).c_str(), color);
}

void Display::DrawLargeNumber(int x, int y, int number, Color color) {
    this->DrawLargeText(x, y, String(number, DEC).c_str(), color);
}

void Display::DrawExtraLargeNumber(int x, int y, int number, Color color) {
    this->DrawExtraLargeText(x, y, String(number, DEC).c_str(), color);
}

void Display::DrawNumber(int x, int y, long number, Color color) {
    this->DrawText(x, y, String(number, DEC).c_str(), color);
}

void Display::DrawLargeNumber(int x, int y, long number, Color color) {
    this->DrawLargeText(x, y, String(number, DEC).c_str(), color);
}

void Display::DrawExtraLargeNumber(int x, int y, long number, Color color) {
    this->DrawExtraLargeText(x, y, String(number, DEC).c_str(), color);
}
