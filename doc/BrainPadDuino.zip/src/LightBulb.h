#pragma once

#include "Color.h"

namespace Implementation {
    class LightBulb {
        int r;
        int g;
        int b;

    public:
        LightBulb();

        void SetColor(Color color);
        void SetColor(double r, double g, double b);
        void TurnOn();
        void TurnOff();
    };
}
