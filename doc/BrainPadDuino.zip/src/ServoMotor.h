#pragma once

#ifdef VS
    #include "../Visual Studio/Helpers.h"
#else
    #include <Servo.h>
#endif

namespace Implementation {
    class ServoMotor {
        Servo servo;

    public:
        void SetPosition(int position);
        void Start();
        void Stop();
    };
}
