#include "TrafficLight.h"

#include "Peripherals.h"

#ifdef VS
    #include "../Visual Studio/Helpers.h"
#else
    #include <Arduino.h>
#endif

using namespace Implementation;

TrafficLight::TrafficLight() {
    pinMode(::Peripherals.TrafficLight.Red, OUTPUT);
    pinMode(::Peripherals.TrafficLight.Yellow, OUTPUT);
    pinMode(::Peripherals.TrafficLight.Green, OUTPUT);
}

void TrafficLight::TurnRedLightOn() {
    this->TurnColorOn(Color::Red);
}

void TrafficLight::TurnRedLightOff() {
    this->TurnColorOff(Color::Red);
}

void TrafficLight::TurnYellowLightOn() {
    this->TurnColorOn(Color::Yellow);
}

void TrafficLight::TurnYellowLightOff() {
    this->TurnColorOff(Color::Yellow);
}

void TrafficLight::TurnGreenLightOn() {
    this->TurnColorOn(Color::Green);
}

void TrafficLight::TurnGreenLightOff() {
    this->TurnColorOff(Color::Green);
}

void TrafficLight::TurnOffAllLights() {
    this->TurnRedLightOff();
    this->TurnYellowLightOff();
    this->TurnGreenLightOff();
}

void TrafficLight::TurnColorOn(Color color) {
    SetColor(color, 255);
}

void TrafficLight::TurnColorOff(Color color) {
    SetColor(color, 0);
}

void TrafficLight::SetColor(Color color, int level) {
    if (color.R != 0 && color.G == 0 && color.B == 0) {
        analogWrite(::Peripherals.TrafficLight.Red, level);
    }
    else if (color.R != 0 && color.G != 0 && color.B == 0) {
        analogWrite(::Peripherals.TrafficLight.Yellow, level);
    }
    else if (color.R == 0 && color.G != 0 && color.B == 0) {
        analogWrite(::Peripherals.TrafficLight.Green, level);
    }
}
