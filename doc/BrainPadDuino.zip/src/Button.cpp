#include "Button.h"

#include "Peripherals.h"

#ifdef VS
    #include "../Visual Studio/Helpers.h"
#else
    #include <Arduino.h>
#endif

using namespace Implementation;

Button::Button() {
    this->DPad.Down = ::Peripherals.Button.Down;
    this->DPad.Up = ::Peripherals.Button.Up;
    this->DPad.Left = ::Peripherals.Button.Left;
    this->DPad.Right = ::Peripherals.Button.Right;

    pinMode(this->DPad.Down, INPUT_PULLUP);
    pinMode(this->DPad.Up, INPUT_PULLUP);
    pinMode(this->DPad.Left, INPUT_PULLUP);
    pinMode(this->DPad.Right, INPUT_PULLUP);
}

bool Button::IsDownPressed() {
    return this->IsPressed(this->DPad.Down);
}

bool Button::IsUpPressed() {
    return this->IsPressed(this->DPad.Up);
}

bool Button::IsLeftPressed() {
    return this->IsPressed(this->DPad.Left);
}

bool Button::IsRightPressed() {
    return this->IsPressed(this->DPad.Right);
}

bool Button::IsPressed(int button) {
    if (button != this->DPad.Down && button != this->DPad.Up && button != this->DPad.Left && button != this->DPad.Right) return false;

    return digitalRead(button) == LOW;
}
