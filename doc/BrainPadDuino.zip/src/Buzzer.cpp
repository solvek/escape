#include "Buzzer.h"

#include "Peripherals.h"

#ifdef VS
    #include "../Visual Studio/Helpers.h"
#else
    #include <Arduino.h>
#endif

using namespace Implementation;

Buzzer::Buzzer() {
    this->Volume.Loud = 1;
    this->Volume.Quiet = 0;

    this->Note.A = 880;
    this->Note.ASharp = 932;
    this->Note.B = 988;
    this->Note.C = 1047;
    this->Note.CSharp = 1109;
    this->Note.D = 1175;
    this->Note.DSharp = 1244;
    this->Note.E = 1319;
    this->Note.F = 1397;
    this->Note.FSharp = 1480;
    this->Note.G = 1568;
    this->Note.GSharp = 1661;

    this->playing = false;

    pinMode(::Peripherals.BuzzerVolumeController, OUTPUT);
}

void Buzzer::SetVolume(int volume) {
    digitalWrite(::Peripherals.BuzzerVolumeController, volume == this->Volume.Quiet);
}

void Buzzer::PlayNote(int note) {
    this->PlayFrequency(note);
}

void Buzzer::PlayFrequency(int frequency) {
    if (frequency != 0.0) {
        if (this->playing)
            this->Stop();

        tone(::Peripherals.Buzzer, frequency);

        this->playing = true;
    }
    else {
        this->Stop();
    }
}

void Buzzer::Stop() {
    this->playing = false;

    noTone(::Peripherals.Buzzer);
}
