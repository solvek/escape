#include "TemperatureSensor.h"

#include "Peripherals.h"

#ifdef VS
    #include "../Visual Studio/Helpers.h"
#else
    #include <Arduino.h>
#endif

using namespace Implementation;

double TemperatureSensor::ReadTemperature() {
    double sum = 0;

    for (int i = 0; i < 10; i++)
        sum += analogRead(::Peripherals.TemperatureSensor) / 1023.0;

    sum /= 10.0;

    return (sum * 5000.0 - 450.0) / 19.5;
}
