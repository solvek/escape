#pragma once

namespace Implementation {
    class Button {
    public:
        class {
        public:
            int Down;
            int Up;
            int Left;
            int Right;
        } DPad;

        Button();

        bool IsDownPressed();
        bool IsUpPressed();
        bool IsLeftPressed();
        bool IsRightPressed();
        bool IsPressed(int button);
    };
}
