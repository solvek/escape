#pragma once

#include "Color.h"

class Image {
public:
    int Width;
    int Height;
    unsigned char* Pixels;

    Image(int width, int height);
    ~Image();

    void SetPixel(int x, int y, Color color);
};
