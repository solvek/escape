#include "LightSensor.h"

#include "Peripherals.h"

#ifdef VS
    #include "../Visual Studio/Helpers.h"
#else
    #include <Arduino.h>
#endif

using namespace Implementation;

double LightSensor::ReadLightLevel() {
    return analogRead(::Peripherals.LightSensor) / 1023.0;
}
