#include "Image.h"

Image::Image(int width, int height) {
    if (width <= 0) width = 1;
    if (height <= 0) height = 1;

    this->Width = width;
    this->Height = height;
    this->Pixels = new unsigned char[width * height * 2];

    for (int i = 0; i < width * height * 2; i++)
        this->Pixels[i] = 0;
}

Image::~Image() {
    if (this->Pixels != 0)
        delete[] this->Pixels;
}

void Image::SetPixel(int x, int y, Color color) {
    if (x < 0 || x > this->Width) return;
    if (y < 0 || y > this->Height) return;

    this->Pixels[(y * this->Width + x) * 2 + 0] = (unsigned char)(color.As565() >> 8);
    this->Pixels[(y * this->Width + x) * 2 + 1] = (unsigned char)(color.As565() >> 0);
}
