#pragma once

#include "Color.h"
#include "Image.h"

#ifdef VS
    #include "../Visual Studio/Helpers.h"
#else
    #include <SPI.h>
#endif

namespace Implementation {
    class Display {
        unsigned char buffer1[1];
        unsigned char buffer2[2];
        unsigned char buffer4[4];
        unsigned char characterBuffer1[80];
        unsigned char characterBuffer2[320];
        unsigned char characterBuffer4[1280];
        unsigned char clearBuffer[160 * 2];

        SPISettings settings;

        const unsigned char ST7735_MADCTL = 0x36;
        const unsigned char MADCTL_MY = 0x80;
        const unsigned char MADCTL_MX = 0x40;
        const unsigned char MADCTL_MV = 0x20;
        const unsigned char MADCTL_BGR = 0x08;

        void SpiWrite(unsigned char* buffer, int length);
        void WriteData(unsigned char* data, int length);
        void WriteCommand(unsigned char command);
        void WriteData(unsigned char data);
        void Reset();
        void SetClip(int x, int y, int width, int height);
        void DrawLetter(int x, int y, char letter, Color color, int scaleFactor);

    public:
        const int Width = 160;
        const int Height = 128;

        Display();

        void Clear();
        void TurnOn();
        void TurnOff();
        void SetPixel(int x, int y, Color color);
        void DrawImage(unsigned char* data, int length);
        void DrawImage(int x, int y, const Image& image);
        void DrawLine(int x0, int y0, int x1, int y1, Color color);
        void DrawCircle(int x, int y, int r, Color color);
        void DrawRectangle(int x, int y, int width, int height, Color color);
        void DrawFilledrectangle(int x, int y, int width, int height, Color color);
        void DrawLetter(int x, int y, char letter, Color color);
        void DrawLargeLetter(int x, int y, char letter, Color color);
        void DrawExtraLargeLetter(int x, int y, char letter, Color color);
        void DrawText(int x, int y, const char* text, Color color);
        void DrawLargeText(int x, int y, const char* text, Color color);
        void DrawExtraLargeText(int x, int y, const char* text, Color color);
        void DrawNumber(int x, int y, double number, Color color);
        void DrawLargeNumber(int x, int y, double number, Color color);
        void DrawExtraLargeNumber(int x, int y, double number, Color color);
        void DrawNumber(int x, int y, int number, Color color);
        void DrawLargeNumber(int x, int y, int number, Color color);
        void DrawExtraLargeNumber(int x, int y, int number, Color color);
        void DrawNumber(int x, int y, long number, Color color);
        void DrawLargeNumber(int x, int y, long number, Color color);
        void DrawExtraLargeNumber(int x, int y, long number, Color color);
    };
}
