#pragma once

namespace Implementation {
    class Expansion {
    public:
        Expansion();

        class {
        public:
            int D11;
            int D12;
            int D3;
            int D2;
            int D19;
            int D18;
        } Gpio;

        class {
        public:
            int D11;
            int D12;
            int D3;
            int D2;
        } Pwm;

        class {
        public:
            int A13;
        } AnalogInput;
    };
}

extern Implementation::Expansion Expansion;
